
from django.urls import path
from . import views

urlpatterns = [
    path('', views.cartlist, name='cartlist'),
    path('<int:pk>', views.cart, name='cart'),
    path('remove/<int:pk>', views.remove, name='remove'),
    # path('payment', views.payment, name='payment'),
]