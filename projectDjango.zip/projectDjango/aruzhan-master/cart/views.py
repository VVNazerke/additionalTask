from django.shortcuts import render
from book.models import Book
from .models import Cart
from django.shortcuts import render, redirect


def cart(request,pk):

    books = Book.objects.get(pk=pk)

    if Cart.objects.filter(name=books.name).exists():
        return redirect('/')
    else:
        cart = Cart(image=books.image, name=books.name, price=books.price, discount=books.discount, description=books.description)
        cart.save()
        return redirect('home')

def cartlist(request):
    sum = 0
    sum1 = 0
    sum2 = 0
    carts = Cart.objects.all()
    for i in carts:
        sum += i.price
    sum1=sum
    if sum>10000:
        
       sum1=sum-(sum*0.15)
       sum2=sum*0.15
    return render(request, 'cart.html', {'carts':carts, 'sum':sum, 'sum1':sum1,'sum2':sum2})

def remove(request, pk):
    cart = Cart.objects.get(pk=pk).delete()
    return redirect('cartlist')