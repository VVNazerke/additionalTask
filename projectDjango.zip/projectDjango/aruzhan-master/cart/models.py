from django.db import models

class Cart(models.Model):
    image = models.ImageField(null=True, blank=True)
    name = models.CharField(max_length=100, unique=True)
    price = models.PositiveIntegerField()
    discount = models.PositiveIntegerField()
    description = models.TextField()

    def __str__(self):
        return self.name
